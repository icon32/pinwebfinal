



<?php $__env->startSection('content'); ?>

    <div class="container main-content">

        <div class="container-fluid text-center page-title">
            <h1>Publish a New Post !!!</h1>
        </div>
        <div class="row">

            <!-----          ------>


            <!-----     Left Side     ------>
            <form method="POST" action="/posts/<?php echo e($posts->slug); ?>" enctype="multipart/form-data" class="md-form container-fluid row">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="col-lg-6 blog-left">

                    <div class="container">
                        <div class="text-left" style="height:200px; background-color:grey; padding-top: 15%;  ">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if($errors -> has('image')): ?>
                                    <p style="color: red; background-color: white;" ><?php echo e($errors->first('image')); ?></p>
                                <?php endif; ?>
                            <?php endif; ?>
                            <input class="text-center" value="<?php echo e($posts->image); ?>" type="file" name="image" id="image" style=" color: white; width: auto; position: absolute; margin-left: 40px;" >

                        </div>

                    </div>

                    <div class="container-fluid">

                        <div>
                            <a class="btn previus " href="<?php echo e(url()->previous()); ?>">&#8249; Cancel Post</a>
                        </div>

                    </div>

                </div>


                <!-----     Right Side     ------>

                <div class="col-lg-6 blog-right">

                    <div class="coment-input">

                        <div class="form-group ">


                            <div>

                                <textarea class="form-control" name="title" id="title" placeholder="Post Title*..." ><?php echo e($posts->title); ?></textarea>
                                <?php if($errors -> has('title')): ?>
                                    <p style="color: red; background-color: white;"><?php echo e($errors->first('title')); ?></p>
                                <?php endif; ?>
                                <br>
                                <textarea class="form-control" id="body" name="body" rows="8" style="margin-top:15px;" placeholder="Post Description*..." ><?php echo e($posts->body); ?></textarea>
                                <?php if($errors -> has('body')): ?>
                                    <p style="color: red; background-color: white;"><?php echo e($errors->first('body')); ?></p>
                                <?php endif; ?>
                                <br>



                            </div>
                            <div class="form-group text-center">
                                <?php if(Auth::check()): ?>

                                    <button type="submit" class="btn btn-danger" style="margin-top:5px; width:200px;">Publish!</button>

                                <?php else: ?>
                                    <p style=" color: #721c24; background-color: #721c24; margin-top:10px;">
                                        You have to Login in order to Publish a post
                                    </p>

                                <?php endif; ?>
                            </div>


                        </div>
                    </div>


                </div>
            </form>
            <!-----          ------>
        </div>



    </div>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pinweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pinwebfinal\resources\views/editpost.blade.php ENDPATH**/ ?>