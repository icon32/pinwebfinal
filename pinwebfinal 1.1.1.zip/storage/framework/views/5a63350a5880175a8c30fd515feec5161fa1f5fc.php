<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="">
                <div class="">Control Panel</div>

                <div class="">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <div class="row">
                            <div class="col-md-3">
                                <img style="width: 150px; border-radius: 50%;" src="/img/users/<?php echo e(Auth::user()->avatar); ?>" >
                            </div>
                            <div class="col-auto">
                                <p style="font-weight:900; font-size: 25px;"> Hello <?php echo e(Auth::user()->name); ?> !!!</p>
                            </div>
                        </div>

                    <a href="/profile/<?php echo e(Auth::user()->id); ?>" style="margin-left: 40px; margin-top: 10px" > Profilepage </a>

                </div>

                <img >
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pinweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pinwebfinal\resources\views/controlPanel.blade.php ENDPATH**/ ?>