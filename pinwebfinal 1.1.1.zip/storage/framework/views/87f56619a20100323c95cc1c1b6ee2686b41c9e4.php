<?php $__env->startSection('content'); ?>


    <!--- Main Content Area Start -->
    <div class="container main-content">
        <div class="row">

            <div class="col-lg-6 text-center">
                <div class="profile-img-div justify-content-center text-center" id="avatardiv">
                    <img class="profile-image" id="avatar-preview" src="/img/users/<?php echo e($user ->avatar); ?>"  style="object-fit: cover;" alt="Card image cap">
                </div>
                <div class="container-fluid text-center">
                    <?php if($user ->id == $currentuser ): ?>
                        <button type="button" id="changeavatar" class="btn btn-secondary editbtn" style="width:200px; margin-top: 5px;">Change Avatar</button>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-6 blog-right">
                <div class="row">
                    <div class="col-auto text-left" id="name_editp">
                        <p id="username">
                            <span style="font-weight: bold; font-size: large;"><?php echo e($user ->name); ?> </span>
                        </p>
                    </div>
                    <div class="col-8" id="namebtn">
                        <?php if($user ->id == $currentuser): ?>

                            <button type="button" id="editnamebtn"  class="btn btn-secondary editbtn" style="font-size: 11px; line-height: 14px; padding: 0px; height: 20px; width:50px;">Edit</button>

                        <?php endif; ?>
                    </div>

                </div>
                <div>
                    <p>Joined At : <?php echo e($user ->created_at->format('d-m-Y')); ?> </p>
                </div>
                <div>
                    <p>Total Likes: <?php echo e($user ->total_likes); ?></p>
                </div>
                <div class="blog-desc" id="blog-desc" >

                    <p id="edidescription"> <?php echo e($user ->description); ?>

                        <?php if(auth()->guard()->check()): ?>
                            <?php if($user ->id == $currentuser): ?>
                                <button type="button" id="editbodybtn" class="btn btn-secondary editbtn" style="font-size: 11px; line-height: 14px; padding: 0px; height: 20px; width:50px;">Edit</button>
                            <?php endif; ?>
                         <?php endif; ?>
                    </p>
                </div>
                <hr>
                <div class="container-fluid ">
                    <h2>Users Post's</h2>
                </div>
                <div class="container">
                    <div class="container-fluid">
                        <div class="row">

                            <div class="card-columns profile-cards" >


                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card text-center justify-content-center">
                                        <img class="card-img-top" src="/img/posts/<?php echo e($post->image); ?>" alt="Card image cap">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-sm-10">
                                                    <h5 class="card-title text-left"><a href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h5>
                                                </div>
                                                <div class="col-sm-2 text-right ">
                                                    <svg data-html="true" data-toggle="tooltip" title="<?php echo e($post->slug); ?> <br> Likes <?php echo e($post->total_likes); ?> <br> Comments <?php echo e($post->total_comments); ?> " class="bi bi-three-dots text-right" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" d="M3 9.5a1.5 1.5 0 110-3 1.5 1.5 0 010 3zm5 0a1.5 1.5 0 110-3 1.5 1.5 0 010 3zm5 0a1.5 1.5 0 110-3 1.5 1.5 0 010 3z" clip-rule="evenodd"/>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>

                            <?php echo e($posts->links()); ?>

                        </div>
                    </div>




                </div>



            </div>

        </div>


        <script>
            


                

                $("#editnamebtn").click(function(){

                    let nameform = '<form method="POST" action="/profile/<?php echo e($user->name); ?>/edit/name"  class="container-fluid row" >' +
                            '<?php echo csrf_field(); ?>' +
                            '<?php echo method_field('PUT'); ?>' +
                    '<input type="text" id="name" name="name" value="<?php echo e($user->name); ?>"> ' +
                    '<button type="submit" id="editnamebtn"  class="btn btn-secondary editbtn" style="font-size: 11px; line-height: 14px; padding: 0px; height: 20px; width:50px;">Save</button>' +
                    ' </form>';

                    $("#username").remove();
                    $("#editnamebtn").remove();
                    $("#name_editp").append(nameform);
                });




                

                    $("#editbodybtn").click(function(){


                        let nameform = ' <form method="POST" action="/profile/<?php echo e($user->name); ?>/edit/desc" enctype="multipart/form-data" class="md-form container-fluid row">  ' +
                            '<?php echo csrf_field(); ?>'+
                            '<?php echo method_field('PUT'); ?>'+
                            '<textarea class="form-control" id="description" name="description" rows="8" style="margin-top:15px;" placeholder="Post Description*..." >  </textarea> ' +
                            '<button type="submit" class="btn btn-secondary edidescription" ' +
                            'style="font-size: 11px; line-height: 14px; padding: 0px; height: 20px; width:50px;">Save!</button>' +
                            ' </form>';
                        $("#edidescription").remove();
                        $("#editbodybtn").remove();
                        $("#blog-desc").append(nameform);
                    });


                

                $("#changeavatar").click(function(){



                    let nameform = ' <form method="POST" action="/profile/<?php echo e($user->name); ?>/edit/avatar" enctype="multipart/form-data" class="md-form container-fluid row">  ' +
                        '<?php echo csrf_field(); ?>'+
                        '<?php echo method_field('PUT'); ?>'+
                            '<div class="row">'+
                            '<div class="container">'+
                        '<input class="text-center"  type="file"  name="avatar" id="avatar" style=" color: white; width: auto; position: absolute; margin-left: 40px;" > ' +
                            '</div>'+
                            '<div >' +
                        '<button type="submit" class="btn btn-secondary edidescription" ' +
                        'style="font-size: 11px; line-height: 14px; padding: 0px; height: 20px; width:50px;">Save!</button>' +
                            '</div>'+
                            '</div>'+
                        ' </form>';
                    $("#edidavatar").remove();
                    $("#changeavatar").remove();
                    $("#avatardiv").append(nameform);


                });

                    $(document).ready(function(){

                        $('[data-toggle="tooltip"]').tooltip();

                    });




    






        </script>

    <!--- Main Content Area End -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pinweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pinwebfinal\resources\views/profile.blade.php ENDPATH**/ ?>