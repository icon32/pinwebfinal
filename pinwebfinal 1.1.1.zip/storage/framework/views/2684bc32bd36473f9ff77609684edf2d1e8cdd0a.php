



<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Search Results</h1>
    <div class="row">

        <?php if($postscount == 0 && $userscount == 0 ): ?>

            <div class="col-6">
                <h2>Nothing Found</h2>
                We Found no Users or  Posts <br>

            </div>
        <?php else: ?>

        <?php if($postscount > 0): ?>
        <div class="col-6">
            <h2>Posts</h2>
            We Found <?php echo e($postscount); ?> Posts <br>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <p><a href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></p>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <?php if($userscount > 0): ?>
        <div class="col-6">

            <h2>Users</h2>
            we found <?php echo e($userscount); ?> users <br>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <p><a href="/profile/<?php echo e($user->id); ?>"><?php echo e($user->name); ?></a></p>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
        <?php endif; ?>

        <?php endif; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pinweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pinwebfinal\resources\views/searchResults.blade.php ENDPATH**/ ?>