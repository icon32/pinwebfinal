



<?php $__env->startSection('content'); ?>

<!--- Main Content Area Start -->

<div class="container main-content">
        <div class="row">

            <div class="col-lg-6 blog-left">

                <div class="blog-img">
                    <img class="card-img-top" src="/img/posts/<?php echo e($posts->image); ?>" style="object-fit: cover;" alt="Card image cap">
                </div>

                <div class="container-fluid">
                    <div class="row blog-und-img ">
                        <div class="col-3">
                            <a class="btn previus " href="<?php echo e(url()->previous()); ?>">&#8249; Back</a>
                        </div>
                        <div class="col text-right">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if($user->id == $posts->user_id): ?>
                                <a type="button" class="btn btn-secondary editbtn" href="<?php echo e(url('/posts/'. $posts->slug).'/edit'); ?>" >Edit Post</a>
                            <?php endif; ?>
                        <?php endif; ?>


                        </div>
                        <div class="col-4">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if($user->id == $posts->user_id): ?>
                                     <a type="button" class="btn btn-danger editbtn" href="<?php echo e(url('/posts-delete/'. $posts->slug)); ?>"> Remove Post </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-lg-6 blog-right">
                <div class="row" >




                            <div class="col-md-7 blog-date-head ">
                                <p style="margin-bottom: 0px;">
                                    <?php echo e($posts->created_at->format('d-m-Y')); ?>

                                </p>

                            </div>

                            <div class="col-sm-3 text-right blog-date-head-right" >
                                <p>
                                    <span id="likes_span" style="font-weight: bold; font-size: large;"><?php echo e($posts->total_likes); ?>! Likes</span>
                                </p>
                            </div>

                            <div class="col-sm-2 text-right blog-date-head-right" id="likediv" style="padding-left: 0px;margin-left: 0px;">


                                <?php if(auth()->guard()->check()): ?>

                                    <?php if($likes): ?>
                                        <button  class="like-Unlike btn btn-danger"   >Unlike</button>

                                    <?php else: ?>
                                        <button  class="like-Unlike btn btn-danger"   >Like</button>
                                    <?php endif; ?>
                                <?php endif; ?>


                            </div>

                </div>
                <div class="row">

                    <h1 style="text-transform: capitalize;"><?php echo e($posts->title); ?></h1>

                </div>
            <div class="blog-desc">

                    <p><?php echo e($posts->body); ?>

                    </p>
                </div>
                <div class="blog-comments">

                    <span style="font-weight: bold; font-size: x-large;">Comments</span>
                </div>

                <div class="blog-comments">
                    <div class="container">
                        <div class="row">
                        <?php $__currentLoopData = $posts->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <div class="col-1">
                                <div class="text-left">
                                    <img src="/img/users/<?php echo e($comment->user_avatar); ?>" class=" round comment-img" alt="...">
                                </div>
                            </div>

                            <div class="col-11 ">

                                <div class="row ">
                                    <div class="col-3 text-justify" style="text-align: left;">
                                        <a href="/profile/<?php echo e($comment->user_id); ?>"><p><?php echo e($comment->user_name); ?> </p></a>
                                    </div>

                                    <div class="col-6 text-muted">
                                        <p><?php echo e($comment->created_at->format('d-m-Y')); ?></p>
                                    </div>
                                </div>


                                <div>
                                    <p> <?php echo e($comment->body); ?></p>
                                </div>

                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>


                <div class="coment-input">
                    <?php if(Auth::check()): ?>

                        <form method="post" action="/comments/create"  class=" ">
                            <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Submit a Comment</label>
                            <input type="hidden" name="post_id" value="<?php echo e($posts->id); ?>">


                            <textarea class="form-control" id="coment-form" name="comment" rows="3"></textarea>
                            <?php if($errors -> has('comment')): ?>
                                <p style="color: red; background-color: white;" ><?php echo e($errors->first('comment')); ?></p>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-primary mb-2 float-right" style="margin-top:5px;">Add Comment</button>

                        </div>
                    </form>
                     <?php else: ?>
                    <?php endif; ?>
                </div>

            </div>



        </div>

    </div>

    </div>
    </div>
    <!--- Main Content Area End -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>


    $(document).ready(function (){

        $(".like-Unlike").click(function(e) {

            console.log(e);

            if ($(this).html() == "Like") {

                $.ajaxSetup({
                    headers:{
                        'X-CSRF-TOKEN':$("meta[name='csrf-token']").attr('content')
                    }
                });

                $.ajax({
                    url:"<?php echo e(url('/postliked')); ?>",
                    method:"POST",
                    data: {post_id: <?php echo e($posts->id); ?> },
                    success:function (result) {
                        console.log(result);
                        result
                        $(likes_span).html(result +"! Likes");
                        }
                    })
                $(this).html('Unlike');


            }
            else {

                $.ajaxSetup({
                    headers:{
                        'X-CSRF-TOKEN':$("meta[name='csrf-token']").attr('content')
                    }
                });

                $.ajax({
                    url:"<?php echo e(url('/postunliked')); ?>",
                    method:"POST",
                    data: {post_id: <?php echo e($posts->id); ?> },
                    success:function (result) {
                        console.log(result);
                        $(likes_span).html(result +"! Likes");
                    }
                })
                $(this).html('Like');

            }

        });


    })



</script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.pinweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pinwebfinal\resources\views/singlepost.blade.php ENDPATH**/ ?>