<?php $__env->startSection('content'); ?>


    <!--- Main Content Area Start -->
    <div class="container main-content">
        <div class="row">

                <div class="col-lg-6 text-center">
                    <form method="put" action="/posts/" enctype="multipart/form-data" class="md-form container-fluid row">
                    <div class="profile-img-con text-center">
                        <img class="card-img-top" src="/img/users/<?php echo e($user->avatar); ?>" style=" margin-top:20px ;width:300px; height: 300px; border-radius: 200px;" alt="Card image cap">
                    </div>

                        <div class="container-fluid text-center">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                            <button type="button" class="btn btn-secondary editbtn" style="width:200px; margin-top: 5px;">Change Image</button>

                        </div>
            </form>
                </div>
                <div class="col-lg-6 blog-right">
                    <div class="row">
                        <div class="col-4 text-left">
                            <p>
                                <span style="font-weight: bold; font-size: large;"><?php echo e($user->name); ?> </span>
                            </p>
                        </div>
                        <div class="col-8">
                            <button type="button" class="btn btn-secondary editbtn" style="font-size: 11px; line-height: 14px; padding: 0px; height: 20px; width:50px;">Edit</button>
                        </div>

                    </div>
                    <div>
                        <p>Joined At : <?php echo e($user->created_at->format('d-m-Y')); ?> </p>
                    </div>
                    <div>
                        <p>Total Likes: <?php echo e($user->total_likes); ?></p>
                    </div>
                    <div class="blog-desc">

                        <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type
                            specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum
                            passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<button type="button" class="btn btn-secondary editbtn" style="font-size: 11px; line-height: 14px; padding: 0px; height: 20px; width:50px;">Edit</button>
                        </p>
                    </div>
                    <hr>
                    <div class="container-fluid ">
                        <h2>Users Post's</h2>
                    </div>
                        <div class="container">
                            <div class="container">
                                <div class="row">

                                    <div class="card-columns" style="column-count: 3!important;">

                                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="card">
                                                <img class="card-img-top" src="/img/posts/<?php echo e($post->image); ?>" alt="Card image cap">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <h5 class="card-title text-left"><a href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h5>
                                                        </div>
                                                        <div class="col-sm-6 text-right ">
                                                            <svg class="bi bi-three-dots text-right" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                                                <path fill-rule="evenodd" d="M3 9.5a1.5 1.5 0 110-3 1.5 1.5 0 010 3zm5 0a1.5 1.5 0 110-3 1.5 1.5 0 010 3zm5 0a1.5 1.5 0 110-3 1.5 1.5 0 010 3z" clip-rule="evenodd"/>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>

                                </div>
                            </div>




                         </div>
                </div>


            </div>

        </div>


    <!--- Main Content Area End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pinweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pinwebfinal\resources\views/editprofile.blade.php ENDPATH**/ ?>