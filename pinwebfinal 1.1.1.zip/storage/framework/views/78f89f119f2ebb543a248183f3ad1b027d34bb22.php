


<?php $__env->startSection('content'); ?>

<!--- Main Content Area Start -->
<div class="container">
        <div class="row">

            <div class="card-columns">

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <img class="card-img-top" loading="lazy" src="img/posts/<?php echo e($post->image); ?>" alt="Card image cap">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-10">
                                <h5 class="card-title text-left"><a href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h5>
                            </div>
                            <div class="col-sm-2 text-right " id="dots">
                                <svg data-html="true" data-toggle="tooltip" title="<?php echo e($post->slug); ?> <br> Likes <?php echo e($post->total_likes); ?> <br> Comments <?php echo e($post->total_comments); ?> "  class="bi bi-three-dots text-right" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">



                                 <path  fill-rule="evenodd" d="M3 9.5a1.5 1.5 0 110-3 1.5 1.5 0 010 3zm5 0a1.5 1.5 0 110-3 1.5 1.5 0 010 3zm5 0a1.5 1.5 0 110-3 1.5 1.5 0 010 3z" clip-rule="evenodd"/>

                              </svg>


                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>

</div>






    <!--- Main Content Area End -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pinweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pinwebfinal\resources\views/pinhome.blade.php ENDPATH**/ ?>